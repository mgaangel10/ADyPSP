package com.example.repasoExamen;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RepasoExamenApplicationTests {

	@Test
	void contextLoads() {
	}

}
