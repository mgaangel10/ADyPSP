package com.example.ejemploDeLuismiConJson;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjemploDeLuismiConJsonApplicationTests {

	@Test
	void contextLoads() {
	}

}
