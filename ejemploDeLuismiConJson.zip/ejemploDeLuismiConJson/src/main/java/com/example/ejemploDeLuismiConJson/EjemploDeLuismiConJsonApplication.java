package com.example.ejemploDeLuismiConJson;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EjemploDeLuismiConJsonApplication {

	public static void main(String[] args) {
		SpringApplication.run(EjemploDeLuismiConJsonApplication.class, args);
	}

}
