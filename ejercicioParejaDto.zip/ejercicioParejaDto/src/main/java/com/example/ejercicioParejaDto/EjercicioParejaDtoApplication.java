package com.example.ejercicioParejaDto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EjercicioParejaDtoApplication {

	public static void main(String[] args) {
		SpringApplication.run(EjercicioParejaDtoApplication.class, args);
	}

}
