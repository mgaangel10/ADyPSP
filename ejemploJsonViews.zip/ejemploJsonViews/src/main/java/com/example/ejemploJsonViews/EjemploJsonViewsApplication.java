package com.example.ejemploJsonViews;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EjemploJsonViewsApplication {

	public static void main(String[] args) {
		SpringApplication.run(EjemploJsonViewsApplication.class, args);
	}

}
