package com.example.ejercicioCasaLambdaStream;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjercicioCasaLambdaStreamApplicationTests {

	@Test
	void contextLoads() {
	}

}
