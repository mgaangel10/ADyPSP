package com.example.ejercicioCasaLambdaStream;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EjercicioCasaLambdaStreamApplication {

	public static void main(String[] args) {
		SpringApplication.run(EjercicioCasaLambdaStreamApplication.class, args);
	}

}
