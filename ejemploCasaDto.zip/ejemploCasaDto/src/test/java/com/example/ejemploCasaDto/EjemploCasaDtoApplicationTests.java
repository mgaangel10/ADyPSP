package com.example.ejemploCasaDto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjemploCasaDtoApplicationTests {

	@Test
	void contextLoads() {
	}

}
