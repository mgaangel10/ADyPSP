package com.example.ejemploCasaDto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EjemploCasaDtoApplication {

	public static void main(String[] args) {
		SpringApplication.run(EjemploCasaDtoApplication.class, args);
	}

}
